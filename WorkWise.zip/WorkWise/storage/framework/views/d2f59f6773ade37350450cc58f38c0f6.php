<div class="navbar">
    <a href="<?php echo e(url('/userhome')); ?>" class="<?php echo e(Request::is('userhome') ? 'active-link' : ''); ?>">Home</a>
    <a href="<?php echo e(url('/savedjobview')); ?>" class="<?php echo e(Request::is('savedjobview') ? 'active-link' : ''); ?>">Saved Jobs</a>
    <a href="<?php echo e(url('/myjobsview')); ?>" class="<?php echo e(Request::is('myjobsview') ? 'active-link' : ''); ?>">My Jobs</a>
    <a href="<?php echo e(url('/surf')); ?>" class="<?php echo e(Request::is('surf') ? 'active-link' : ''); ?>">Find Work</a>


    <div class="logout-btn-container">
        <a href="<?php echo e(route('user.logout')); ?>" onclick="event.preventDefault();document.getElementById('logout-form').submit();"
            class="logout-btn">Logout</a>
        <form action="<?php echo e(route('user.logout')); ?>" method="post" class="d-none" id="logout-form"><?php echo csrf_field(); ?></form>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\WorkWise\resources\views/dashboard/user/navbar.blade.php ENDPATH**/ ?>