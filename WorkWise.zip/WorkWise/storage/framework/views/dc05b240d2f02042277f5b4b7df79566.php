<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Refer Jobs</title>


    <style>

body {
      font-family: Arial, sans-serif;
      margin: 0;
      padding: 0;
      background-color: #f4f4f4;
    }



    header {
      text-align: center;
      padding: 5px;
      margin-left: 40px;
      margin-right: 40px;
      border-radius: 20px;
      margin-top: 20px;
      background-color: #c4c4c4;
      color: #000000;
    }

    #company-name {
      font-size: 24px;
      color: #8e8e8e;
    }

    img {
  display: block;
  margin: 20px auto; /* Center the image horizontally */
  width: 300px;
}

    section {
      padding: 20px;
      background-color: #fff;
      margin: 20px;
      border-radius: 8px;
      box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    }

    h2 {
      color: #333;
    }

    p {
      color: #555;
    }


    .savejobbutton input{
        background: rgb(255, 153, 0);
        color: #fff;
    }

    .savejobbutton input:hover
    {
        background: rgb(255, 0, 0);
        color: #fff;
    }

    .savejobbutton2 input{
        background: rgb(21, 255, 0);
        color: #fff;
    }

    .savejobbutton2 input:hover
    {
        background: rgb(0, 94, 25);
        color: #fff;
    }


    </style>

<?php echo $__env->make('dashboard.user.navbarstyle', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



</head>
<body>
    <?php echo $__env->make('dashboard.user.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <form action="<?php echo e(url('/savejobs',$data->id)); ?>" method="post" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>


    <header>
        <h1  name="jobTitle"><?php echo e($data->title); ?></h1>
        <p id="company-name" name="companyName"><?php echo e($data->name); ?></p>
      </header>

      <img name="image" src="<?php echo e(asset('comlogo/' . $data->image)); ?>" alt="Job 1 Image">



      <section>
        <h2>Job Description</h2>
        <p  name="jobDescription" id="jobDescription"><?php echo e($data->description); ?></p>
      </section>

      <section>
        <h2>Salary</h2>
        <p name="salary"><?php echo e($data->salary); ?></p>
      </section>

      <section>
        <h2>Tags</h2>
        <p  name="tags"><?php echo e($data->tag); ?></p>
      </section>

      <section>
        <h2>Job Requirements</h2>
        <p name="jobRequirements"><?php echo e($data->requirement); ?></p>
      </section>

      <section>
        <h2>How to Apply</h2>
        <p name="howToApply"><?php echo e($data->apply); ?></p>
      </section>


      <div style="text-align: center" class="savejobbutton">
        <input type="submit" value="Save Job" style="width: 20%; padding: 20px; margin: 20px; border-radius: 20px">
      </div>




    </form>


    <form action="<?php echo e(url('/applyforjobview',$data->id)); ?>" method="get" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>


        <div style="text-align: center" class="savejobbutton2">
            <input type="submit" value="Apply For Job" style="width: 20%; padding: 20px; margin: 20px; border-radius: 20px">
          </div>



    </form>




</body>
</html>
<?php /**PATH C:\xampp\htdocs\WorkWise\resources\views/dashboard/user/referjob.blade.php ENDPATH**/ ?>