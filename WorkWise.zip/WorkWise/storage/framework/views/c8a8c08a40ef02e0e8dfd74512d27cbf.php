<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Client Dashboard | Home</title>
    <script src="https://kit.fontawesome.com/b99e675b6e.js"></script>
    <link rel="stylesheet" href="<?php echo e(asset('bootstrap.min.css')); ?>">

    <?php echo $__env->make('dashboard.admin.style', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>

<body>
    <div class="wrapper">
        <div class="sidebar">
            <h2><?php echo e(Auth::guard('admin')->user()->name); ?></h2>
            <ul>
                <li><a href="<?php echo e(url('/admin/home')); ?>"><i class="fas fa-home"></i>Home</a></li>
                <li><a href="<?php echo e(url('/addcv')); ?>"><i class="fas fa-plus-circle"></i>Add Clients</a></li>
                <li><a href="<?php echo e(url('/addfv')); ?>"><i class="fas fa-plus"></i>Add Freelancers</a></li>
                <li><a href="<?php echo e(url('/manageclient')); ?>"><i class="fas fa-user-secret"></i>Manage Clients</a></li>
                <li><a href="<?php echo e(url('/managefreelancer')); ?>"><i class="fas fa-user"></i>Manage Freelancers</a></li>
                <li><a href="<?php echo e(url('/managejobsview')); ?>"><i class="fas fa-briefcase"></i>Manage Jobs</a></li>
                <li><a href="#"><i class="fas fa-blog"></i>Blogs</a></li>
                <li><a href="#"><i class="fas fa-address-book"></i>Contact</a></li>
                <li><a href="#"><i class="fas fa-map-pin"></i>Map</a></li>
            </ul>

        </div>
        <div class="main_content">
            <div class="header">Manage Freelancer</div>

            <table class="table" style="margin: 20px; width: 55%">
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Email</th>
                        <th style="width: 120px">Update</th>
                        <th style="width: 120px">Delete</th>
                    </tr>
                </thead>
                <tbody>




                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>




                    <tr>
                        <td><?php echo e($data->name); ?></td>
                        <td><?php echo e($data->email); ?></td>
                        <td><a href="<?php echo e(url('/updatefreelancerview',$data->id)); ?>" style="background-color: rgb(34, 255, 0); color: white; padding: 10px; border: none; cursor: pointer; border-radius: 5px;">Update</a></td>
                        <td><a href="<?php echo e(url('/admindeletefreelancer',$data->id)); ?>" style="background-color: rgb(255, 0, 0); color: white; padding: 10px; border: none; cursor: pointer; border-radius: 5px;">Delete</a></td>
                    </tr>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



                </tbody>
            </table>


        </div>
    </div>

    <br><br>

</body>
</html>



<?php /**PATH C:\xampp\htdocs\WorkWise\WorkWise\resources\views/dashboard/admin/managefreelancer.blade.php ENDPATH**/ ?>