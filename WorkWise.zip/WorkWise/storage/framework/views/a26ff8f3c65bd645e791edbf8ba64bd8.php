<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Freelancer Dashboard | Home</title>
    <link rel="stylesheet" href="<?php echo e(asset('bootstrap.min.css')); ?>">
</head>

<style>

body {
    display: flex;
    flex-wrap: wrap;

}





.job-box {
  border: 1px solid #ccc;
  flex: 0 0 calc(33.3333% - 40px);
  border-radius: 8px;
  box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
  margin: 20px;
  padding: 20px;
  width: 200px;
  height: 250px
  box-sizing: border-box;
  text-align: center;
}

.job-box img {
  width: 100%;
  height: 230px;
  border-radius: 4px;
}

.job-box h3 {
  margin-top: 10px;
  color: #333;
}

a {
    margin-top: 20px;
    font-size: 20px;

}

</style>

<?php echo $__env->make('dashboard.user.navbarstyle', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<body>



    <?php echo $__env->make('dashboard.user.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>






      <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>




    <div class="job-box">
        <img src="<?php echo e(asset('comlogo/' . $data->image)); ?>" alt="Job 1 Image">
        <a href="<?php echo e(url('/moveto',$data->id)); ?>"><?php echo e($data->title); ?></a>
        <p>Salary: <?php echo e($data->salary); ?></p>
      </div>


      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>







</body>
</html>
<?php /**PATH C:\xampp\htdocs\WorkWise\resources\views/dashboard/user/surfjob.blade.php ENDPATH**/ ?>