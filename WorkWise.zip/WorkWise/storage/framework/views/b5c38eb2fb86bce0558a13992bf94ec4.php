<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Client Login</title>
    <link rel="stylesheet" href="<?php echo e(asset('bootstrap.min.css')); ?>">
    <style>
        body {
            background-color: #3c4c5b;
            color: #fff;
            font-family: 'Arial', sans-serif;
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        h2 a {
            color: #fff;
            text-decoration: none;
        }

        h2 a:hover {
            color: #ccc;
        }

        .container {
            margin-top: 50px;
        }

        .col-md-4 {
            background-color: #fff;
            border-radius: 8px;
            padding: 20px;
            box-shadow: 0px 0px 10px 0px #000000;
        }

        h4 {
            text-align: center;
            color: #3c4c5b;
        }

        hr {
            border-color: #3c4c5b;
        }

        form {
            margin-top: 20px;
        }

        label {
            color: #3c4c5b;
        }

        .form-control {
            border-radius: 4px;
        }

        .btn-primary {
            background-color: #3c4c5b;
            border: none;
            width: 100%;
        }

        .btn-primary:hover {
            background-color: #2c3c4b;
        }

        a {
            color: #3c4c5b;
            text-decoration: none;
        }

        a:hover {
            color: #2c3c4b;
        }

        .alert-danger {
            color: #721c24;
            background-color: #f8d7da;
            border-color: #f5c6cb;
            border-radius: 4px;
            padding: 10px;
            margin-bottom: 20px;
        }

        .text-danger {
            color: #721c24;
        }
        a.create-account {
        display: block;
        color:#2c3c4b;
        text-decoration: underline;
        font-family: 'Arial Narrow Bold';
    }

    a.create-account:hover {
        color: rgb(255, 170, 0);
    }
    </style>
</head>
<body>

    <div class="container">
        <div class="row">
            <div class="col-md-4 offset-md-4" style="margin-top: 45px">
                <a href="/"><img src="<?php echo e(asset('gif.gif')); ?>" alt="" width="50px"></a>
                 <h4>Client Login</h4><hr>
                 <form action="<?php echo e(route('client.check')); ?>" method="post">
                    <?php if(Session::get('fail')): ?>
                        <div class="alert alert-danger">
                            <?php echo e(Session::get('fail')); ?>

                        </div>
                    <?php endif; ?>
                    <?php echo csrf_field(); ?>
                     <div class="form-group">
                         <label for="email">Email</label>
                         <input type="text" class="form-control" name="email" placeholder="Enter email address" value="<?php echo e(old('email')); ?>">
                         <span class="text-danger"><?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
                     </div>
                     <div class="form-group">
                         <label for="password">Password</label>
                         <input type="password" class="form-control" name="password" placeholder="Enter password" value="<?php echo e(old('password')); ?>">
                         <span class="text-danger"><?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
                     </div>
                     <div class="form-group">
                         <button type="submit" class="btn btn-primary">Login</button>
                     </div>
                     <br>
                     <a class="create-account" href="<?php echo e(route('client.register')); ?>" >Create new Account</a>

                 </form>
            </div>
        </div>
    </div>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\WorkWise\WorkWise\resources\views/dashboard/client/login.blade.php ENDPATH**/ ?>