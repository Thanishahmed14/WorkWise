<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Freelancer Dashboard | Home</title>
    <link rel="stylesheet" href="<?php echo e(asset('bootstrap.min.css')); ?>">

    <?php echo $__env->make('dashboard.user.style', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</head>

<body>


    <div class="navbar">
        <a href="<?php echo e(url('/userhome')); ?>" class="<?php echo e(Request::is('userhome') ? 'active-link' : ''); ?>">Home</a>
        <a href="<?php echo e(url('/savedjobview')); ?>" class="<?php echo e(Request::is('savedjobview') ? 'active-link' : ''); ?>">Saved Jobs</a>
        <a href="<?php echo e(url('/myjobsview')); ?>" class="<?php echo e(Request::is('myjobsview') ? 'active-link' : ''); ?>">My Jobs</a>
        <a href="<?php echo e(url('/surf')); ?>" class="<?php echo e(Request::is('surf') ? 'active-link' : ''); ?>">Find Work</a>


        <div class="logout-btn-container">
            <a href="<?php echo e(route('user.logout')); ?>" onclick="event.preventDefault();document.getElementById('logout-form').submit();"
                class="logout-btn">Logout</a>
            <form action="<?php echo e(route('user.logout')); ?>" method="post" class="d-none" id="logout-form"><?php echo csrf_field(); ?></form>
        </div>
    </div>

    <div class="container">
        <div class="profile-info">
            <label for="name">Name:</label>
            <p><?php echo e(Auth::guard('web')->user()->name); ?></p>
<br>
            <label for="email">Email:</label>
            <p><?php echo e(Auth::guard('web')->user()->email); ?></p>
        </div>
    </div>

        <!-- Footer section -->
        <footer>
            <p>&copy; 2024 Workwise Freelancer Dashboard. All rights reserved.</p>
        </footer>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\WorkWise\WorkWise\resources\views/dashboard/user/home.blade.php ENDPATH**/ ?>