<div class="wrapper">
    <div class="sidebar">
        <h2>Sidebar</h2>
        <ul>
            <li><a href="#" onclick="window.location.href = '<?php echo e(route('client.home')); ?>'"><i class="fas fa-home"></i>Home</a></li>
            <li><a href="<?php echo e(url('/add')); ?>"><i class="fas fa-plus-circle"></i>Add Jobs</a></li>
            <li><a href="<?php echo e(url('/reveiw')); ?>"><i class="fas fa-exclamation-circle"></i>Reveiw Jobs</a></li>
            <li><a href="<?php echo e(url('/appliedjobsview')); ?>"><i class="fas fa-star"></i>Applied Jobs</a></li>
            <li><a href="#"><i class="fas fa-blog"></i>Blogs</a></li>
            <li><a href="#"><i class="fas fa-address-book"></i>Contact</a></li>
            <li><a href="#"><i class="fas fa-map-pin"></i>Map</a></li>
        </ul>

    </div>
<?php /**PATH C:\xampp\htdocs\WorkWise\resources\views/dashboard/client/navbar.blade.php ENDPATH**/ ?>