<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Freelancer Dashboard | Home</title>
    <link rel="stylesheet" href="<?php echo e(asset('bootstrap.min.css')); ?>">

    <style>
        /* Add your existing styles here */

        table {
            width: 85%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        th, td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }

        th {
            background-color: #333;
            color: white;
        }

        tbody tr:hover {
            background-color: #f5f5f5;
        }
    </style>


   <?php echo $__env->make('dashboard.user.navbarstyle', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</head>

<body>


    <?php echo $__env->make('dashboard.user.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



    <div style="margin: 20px">
        <h2>My Jobs</h2>
        <div class="table-responsive">
            <table class="table table-bordered table-striped">
                <thead>
                    <tr>

                        <th>Job Title</th>
                        <th>Job Company</th>
                        <th>CV</th>
                        <th>Cover Letter</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


                    <tr>

                        <td><?php echo e($data->title); ?></td>
                        <td><?php echo e($data->name); ?></td>
                        <td><a href="<?php echo e(asset('cv/' . $data->cv)); ?>" target="_blank">Download CV</a></td>
                        <td><a href="<?php echo e(asset('cover/' . $data->cover)); ?>" target="_blank">Download Cover Letter</a></td>
                        <td><?php echo e($data->status); ?></td>
                    </tr>


                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>


</body>
</html>
<?php /**PATH C:\xampp\htdocs\WorkWise\resources\views/dashboard/user/myjobsview.blade.php ENDPATH**/ ?>